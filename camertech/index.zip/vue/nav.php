<nav>
    <a href="index.php?page=astuces" title="Les astuces utiles">ASTUCES</a>
    <a href="index.php?page=forum" title="Debatez ici">FORUM</a>
    <a href="index.php?page=tests" title="Resultats de tests des technologies">TESTS</a>
</nav>