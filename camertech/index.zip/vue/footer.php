<footer>
	<section id="footer_section">
		<section>
			<h1>Links</h1>
			<a href="http://www.facebook.com/laPageDeFred" title="Le Facebook de Camtech" target="_blank"><img src="modele/fichiers/images/logo_fcbk.png" /></a>
		</section>
		<section>
			<h1>Pages</h1>
			<ul>
				<li><a href="index.php?page=astuces" title="Les astuces utiles">ASTUCES</a></li>
			    <li><a href="index.php?page=forum" title="Debatez ici">FORUM</a></li>
			    <li><a href="index.php?page=tests" title="Resultats de tests des technologies">TESTS</a></li>
			</ul>
		</section>
		<section>
			<h1>A propos de l'auteur</h1>
			<a href="http://www.cv.com/fred" title="Mon CV" target="_blank">Mon CV</a><br />
			<a href="http://www.facebook.com/levanmboving" title="Mon Facebook" target="_blank"><img src="modele/fichiers/images/logo_fcbk.png" /> Mon Facebook</a>
			<address>Contact: (+237) 696759130</address>
			<address>Email: <a href="mailto:mbovingfred@gmail.com" title="Envoyez moi un mail">mbovingfred@gmail.com</a></address>
			<address>Yaounde, Cameroun</address>
		</section>
	</section>
	<p>&copy;Site web developpé par MBOVING TEGUETIO Levan Fredy</p>
</footer>
<script src="vue/inscription.js"></script>