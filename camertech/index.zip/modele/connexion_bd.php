<?php
    try{
        $bdd = new PDO('mysql:host=sql205.hebergratuit.net;dbname=heber_16559516_camtech', 'heber_16559516', 'sarambang');
    }
    catch(Exception $e){
        die('Erreur: '.$e->getMessage);
    }