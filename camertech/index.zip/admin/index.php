<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Le Titre</title>
        <link rel="stylesheet" href="vue/style.css" />
    </head>
    <body>
        <h1>CamTech Admin</h1>
        <form method="post" action="traitement.php">
            <label for="login">Login</label>:<input type="text" id="login" name="login" /><br />
            <label for="mtp">Mot de passe</label>:<input type="password" id="mtp" name="mtp" /><br />
            <input type="submit" value="Se conncter" />
        </form>
    </body>
</html>